<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Hasil Perbandingan Properti')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-screen-xl mx-auto sm:px-6 lg:px-8">
            
            <div class="mb-6 px-4 sm:px-0">
                <h3 class="text-2xl font-bold text-gray-900 dark:text-gray-100">Perbandingan Kinerja Properti</h3>
                <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Menampilkan hasil perbandingan untuk periode <?php echo e(\Carbon\Carbon::parse($startDate)->isoFormat('D MMMM YYYY')); ?> - <?php echo e(\Carbon\Carbon::parse($endDate)->isoFormat('D MMMM YYYY')); ?>.
                </p>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-<?php echo e(count($properties) > 4 ? 4 : count($properties)); ?> gap-6 mb-8">
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $result = $results->get($property->id); ?>
                    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 flex flex-col justify-between">
                        <div>
                            <div class="flex items-center space-x-3">
                                <div class="p-2 rounded-full" style="background-color: <?php echo e($property->chart_color ?? '#e2e8f0'); ?>20;">
                                    <svg class="w-6 h-6" style="color: <?php echo e($property->chart_color ?? '#94a3b8'); ?>;" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                                </div>
                                <h3 class="font-bold text-lg text-gray-900 dark:text-gray-100"><?php echo e($property->name); ?></h3>
                            </div>
                            <div class="mt-4">
                                <p class="text-sm text-gray-500 dark:text-gray-400">Total Pendapatan</p>
                                <p class="text-3xl font-bold text-gray-900 dark:text-white">Rp <?php echo e(number_format($result->total_overall_revenue ?? 0, 0, ',', '.')); ?></p>
                            </div>
                        </div>
                        <div class="mt-6 border-t dark:border-gray-700 pt-4 space-y-2">
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500 dark:text-gray-400">Okupansi Rata-rata</span>
                                <span class="font-semibold text-gray-700 dark:text-gray-300"><?php echo e(number_format($result->average_occupancy ?? 0, 2)); ?>%</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500 dark:text-gray-400">Average Room Rate</span>
                                <span class="font-semibold text-gray-700 dark:text-gray-300">Rp <?php echo e(number_format($result->average_arr ?? 0, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            
            <div class="grid grid-cols-1 lg:grid-cols-5 gap-6 mb-8">
                <div class="lg:col-span-3 bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 flex flex-col">
                    <h4 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Grafik Perbandingan Pendapatan</h4>
                    
                    <div class="relative mt-4 h-96">
                        <canvas id="comparisonBarChart"></canvas>
                    </div>
                </div>
                <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 flex flex-col">
                    <h4 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Kontribusi Pendapatan</h4>
                     
                    <div class="relative mt-4 h-96">
                        <canvas id="comparisonPieChart"></canvas>
                    </div>
                </div>
            </div>
            


            
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-xl font-semibold mb-4">Rincian Metrik Perbandingan</h3>
                    <div class="overflow-x-auto">
                        
                        <table class="min-w-full">
                            
                            <thead class="border-b-2 border-gray-200 dark:border-gray-700">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                        Metrik
                                    </th>
                                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="px-6 py-3 text-center text-xs font-bold text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            <?php echo e($property->name); ?>

                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <tr class="bg-gray-50 dark:bg-gray-900/50">
                                    <td colspan="<?php echo e(count($properties) + 1); ?>" class="px-6 py-2 text-sm font-semibold text-gray-600 dark:text-gray-300">Pendapatan Kamar</td>
                                </tr>
                                <?php
                                    $metrics = [
                                        'offline' => 'Offline', 'online' => 'Online', 'ta' => 'Travel Agent',
                                        'gov' => 'Government', 'corp' => 'Corporate', 'afiliasi' => 'Afiliasi',
                                    ];
                                ?>
                                <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200"><?php echo e($label); ?></td>
                                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $result = $results->get($property->id);
                                            $revenue = $result ? $result->{$key.'_revenue'} : 0;
                                            $rooms = $result ? $result->{$key.'_rooms'} : 0;
                                        ?>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300 text-center">
                                            <div class="font-semibold">Rp <?php echo e(number_format($revenue, 0, ',', '.')); ?></div>
                                            <?php if($rooms > 0): ?>
                                                <div class="text-xs text-gray-500 dark:text-gray-400 mt-1">(<?php echo e($rooms); ?> kamar)</div>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-gray-100 dark:bg-gray-700/50 font-bold">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">Subtotal Pendapatan Kamar</td>
                                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $result = $results->get($property->id);
                                            $revenue = $result ? $result->total_room_revenue : 0;
                                            $rooms = $result ? $result->total_rooms_sold : 0;
                                        ?>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100 text-center">
                                            <div>Rp <?php echo e(number_format($revenue, 0, ',', '.')); ?></div>
                                            <div class="text-xs font-normal mt-1">(<?php echo e($rooms); ?> kamar)</div>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <tr class="bg-gray-50 dark:bg-gray-900/50">
                                    <td colspan="<?php echo e(count($properties) + 1); ?>" class="px-6 py-2 text-sm font-semibold text-gray-600 dark:text-gray-300">Pendapatan Lainnya</td>
                                </tr>
                                <tr><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">Food & Beverage</td><?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <td class="px-6 py-4 text-center text-sm">Rp <?php echo e(number_format($results->get($property->id)->total_fb_revenue ?? 0, 0, ',', '.')); ?></td> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </tr>
                                <tr><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">MICE/Event</td><?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <td class="px-6 py-4 text-center text-sm">Rp <?php echo e(number_format($results->get($property->id)->total_mice_revenue ?? 0, 0, ',', '.')); ?></td> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </tr>
                                <tr><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">Lain-lain</td><?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <td class="px-6 py-4 text-center text-sm">Rp <?php echo e(number_format($results->get($property->id)->total_others_revenue ?? 0, 0, ',', '.')); ?></td> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </tr>
                                <tr class="bg-indigo-100 dark:bg-indigo-900/30 font-extrabold text-indigo-800 dark:text-indigo-200"><td class="px-6 py-4 whitespace-nowrap text-sm">GRAND TOTAL PENDAPATAN</td><?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <td class="px-6 py-4 text-center text-sm">Rp <?php echo e(number_format($results->get($property->id)->total_overall_revenue ?? 0, 0, ',', '.')); ?></td> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-6">
                        <a href="<?php echo e(route('admin.properties.compare_page')); ?>" class="text-indigo-600 dark:text-indigo-400 hover:underline">
                            &larr; Kembali ke Halaman Pilihan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            // Skrip Javascript Anda dari sebelumnya tidak perlu diubah, saya sertakan kembali untuk kelengkapan
            document.addEventListener('DOMContentLoaded', function () {
                try {
                    const chartData = <?php echo json_encode($chartData, 15, 512) ?>;
                    
                    if (chartData && Array.isArray(chartData) && chartData.length > 0) {
                        const labels = chartData.map(item => item.label);
                        const revenues = chartData.map(item => item.revenue);
                        const colors = chartData.map(item => item.color);

                        const barCanvas = document.getElementById('comparisonBarChart');
                        if (barCanvas) {
                            new Chart(barCanvas.getContext('2d'), {
                                type: 'bar',
                                data: { labels: labels, datasets: [{ label: 'Total Pendapatan', data: revenues, backgroundColor: colors.map(c => c + '99'), borderColor: colors, borderWidth: 1 }] },
                                options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: value => 'Rp ' + new Intl.NumberFormat('id-ID').format(value) } } }, plugins: { legend: { display: false } } }
                            });
                        }

                        const pieCanvas = document.getElementById('comparisonPieChart');
                        if (pieCanvas) {
                            new Chart(pieCanvas.getContext('2d'), {
                                type: 'doughnut',
                                data: { labels: labels, datasets: [{ label: 'Kontribusi Pendapatan', data: revenues, backgroundColor: colors, hoverOffset: 4 }] },
                                options: { responsive: true, maintainAspectRatio: false }
                            });
                        }
                    }
                } catch (e) {
                    console.error('Gagal membuat grafik:', e);
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/admin/properties/compare_results.blade.php ENDPATH**/ ?>