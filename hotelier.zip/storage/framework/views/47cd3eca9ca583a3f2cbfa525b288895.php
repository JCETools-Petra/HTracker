<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex justify-between items-center mb-4">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Manajemen Paket Harga</h2>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-data')): ?>
            <a href="<?php echo e(route('admin.price-packages.create')); ?>" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">+ Tambah Paket</a>
        <?php endif; ?>
    </div>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <table class="min-w-full divide-y divide-gray-200">
            <thead>
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium">Nama Paket</th>
                    <th class="px-6 py-3 text-left text-xs font-medium">Harga</th>
                    <th class="px-6 py-3 text-left text-xs font-medium">Status</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-data')): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-6 py-4"><?php echo e($package->name); ?></td>
                        <td class="px-6 py-4">Rp <?php echo e(number_format($package->price, 0, ',', '.')); ?></td>
                        <td class="px-6 py-4"><?php echo e($package->is_active ? 'Aktif' : 'Tidak Aktif'); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-data')): ?>
                            <td class="px-6 py-4">
                                <a href="<?php echo e(route('admin.price-packages.edit', $package)); ?>" class="text-indigo-600">Edit</a>
                                <form action="<?php echo e(route('admin.price-packages.destroy', $package)); ?>" method="POST" class="inline-block ml-2" onsubmit="return confirm('Hapus paket ini?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600">Hapus</button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-data')): ?> 4 <?php else: ?> 3 <?php endif; ?>" class="px-6 py-4 text-center">
                            Tidak ada paket harga ditemukan.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/admin/price_packages/index.blade.php ENDPATH**/ ?>