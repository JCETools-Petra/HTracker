
<?php
    $isBold = $category['has_children'] || $category['is_payroll'];
    
    // Background Color Logic
    $bgClass = '';
    if ($category['level'] === 0) {
        $bgClass = 'bg-gray-100 dark:bg-gray-700'; // Header Utama (Abu-abu)
    } elseif ($category['is_payroll']) {
        $bgClass = 'bg-yellow-50 dark:bg-yellow-900'; // Payroll (Kuning Tipis)
    } elseif ($category['has_children']) {
        $bgClass = 'bg-gray-50 dark:bg-gray-800'; // Sub-Header
    }

    // Variance Color Logic (PENTING: Membedakan Revenue vs Expense)
    // Expense: Actual > Budget (Positif) = MERAH (Boros)
    // Revenue: Actual > Budget (Positif) = HIJAU (Untung)
    
    $varianceCurrentColor = 'text-gray-500';
    if ($category['variance_current'] != 0) {
        if (($category['type'] ?? 'expense') === 'expense') {
            $varianceCurrentColor = $category['variance_current'] > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400';
        } else {
            $varianceCurrentColor = $category['variance_current'] >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400';
        }
    }

    $varianceYtdColor = 'text-gray-500';
    if ($category['variance_ytd'] != 0) {
        if (($category['type'] ?? 'expense') === 'expense') {
            $varianceYtdColor = $category['variance_ytd'] > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400';
        } else {
            $varianceYtdColor = $category['variance_ytd'] >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400';
        }
    }
?>

<tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors <?php echo e($bgClass); ?>">
    
    <td class="px-6 py-2 text-sm <?php echo e($isBold ? 'font-bold' : ''); ?> text-gray-900 dark:text-gray-100" 
        style="padding-left: <?php echo e(($category['level'] * 1.5 + 1.5)); ?>rem">
        <div class="flex items-center">
            <?php if($category['has_children']): ?>
                <span class="mr-1 text-gray-400 text-xs">▼</span>
            <?php endif; ?>
            
            <?php echo e($category['name']); ?>


            <?php if($category['code']): ?>
                <span class="ml-2 px-1.5 py-0.5 text-[10px] rounded bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 border border-blue-200">Auto</span>
            <?php endif; ?>
            <?php if($category['is_payroll']): ?>
                <span class="ml-2 px-1.5 py-0.5 text-[10px] rounded bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200 border border-yellow-200">Payroll</span>
            <?php endif; ?>
        </div>
    </td>

    
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-900 dark:text-gray-100">
        <?php if($category['actual_current'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['actual_current'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-500 dark:text-gray-400">
        <?php if($category['budget_current'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['budget_current'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-bold' : 'font-medium'); ?> border-r border-gray-200 dark:border-gray-700 <?php echo e($varianceCurrentColor); ?>">
        <?php if($category['variance_current'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['variance_current'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>

    
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-900 dark:text-gray-100">
        <?php if($category['actual_ytd'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['actual_ytd'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-500 dark:text-gray-400">
        <?php if($category['budget_ytd'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['budget_ytd'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-bold' : 'font-medium'); ?> <?php echo e($varianceYtdColor); ?>">
        <?php if($category['variance_ytd'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['variance_ytd'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
</tr>


<?php if($category['has_children'] && count($category['children']) > 0): ?>
    <?php $__currentLoopData = $category['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('financial.partials.category-row', ['category' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/financial/partials/category-row.blade.php ENDPATH**/ ?>