<tr>
    <td class="indent-<?php echo e($category['level']); ?>">
        <?php echo e($category['name']); ?><?php echo e($category['code'] ? ' (Auto)' : ''); ?>

    </td>
    <td class="text-right"><?php echo e(number_format($category['actual_current'], 0)); ?></td>
    <td class="text-right"><?php echo e(number_format($category['budget_current'], 0)); ?></td>
    <td class="text-right <?php echo e($category['type'] === 'revenue' ? ($category['variance_current'] >= 0 ? 'positive' : 'negative') : ($category['variance_current'] <= 0 ? 'positive' : 'negative')); ?>">
        <?php echo e(number_format($category['variance_current'], 0)); ?>

    </td>
    <td class="text-right"><?php echo e(number_format($category['actual_ytd'], 0)); ?></td>
    <td class="text-right"><?php echo e(number_format($category['budget_ytd'], 0)); ?></td>
    <td class="text-right <?php echo e($category['type'] === 'revenue' ? ($category['variance_ytd'] >= 0 ? 'positive' : 'negative') : ($category['variance_ytd'] <= 0 ? 'positive' : 'negative')); ?>">
        <?php echo e(number_format($category['variance_ytd'], 0)); ?>

    </td>
</tr>

<?php $__currentLoopData = $category['children'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('financial.pdf.partials.category-row-pdf', ['category' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\hotelier\resources\views/financial/pdf/partials/category-row-pdf.blade.php ENDPATH**/ ?>