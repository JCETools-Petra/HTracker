<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Pusat Analisis Kinerja (KPI)')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Filter Analisis</h3>
                    <form action="<?php echo e(route('admin.kpi.analysis')); ?>" method="GET">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div class="md:col-span-2">
                                <label for="property_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Pilih Properti</label>
                                <select name="property_id" id="property_id" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                    <option value="">-- Semua Properti --</option>
                                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($property->id); ?>" <?php echo e($propertyId == $property->id ? 'selected' : ''); ?>>
                                            <?php echo e($property->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label for="start_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tanggal Mulai</label>
                                <input type="date" name="start_date" id="start_date" value="<?php echo e($startDate); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-900 dark:border-gray-700 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="end_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tanggal Selesai</label>
                                <input type="date" name="end_date" id="end_date" value="<?php echo e($endDate); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-900 dark:border-gray-700 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                        </div>
                        <div class="mt-4 flex justify-end space-x-2">
                            <a href="#" id="export-excel-btn" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700">
                                Export Excel
                            </a>
                            <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700">
                                Terapkan Filter
                            </button>
                        </div>
                        <script>
                            document.getElementById('export-excel-btn').addEventListener('click', function(e) {
                                e.preventDefault();
                                const form = this.closest('form');
                                const propertyId = form.querySelector('[name="property_id"]').value;
                                const startDate = form.querySelector('[name="start_date"]').value;
                                const endDate = form.querySelector('[name="end_date"]').value;
                                
                                const exportUrl = new URL("<?php echo e(route('admin.kpi.analysis.export')); ?>");
                                exportUrl.searchParams.append('property_id', propertyId);
                                exportUrl.searchParams.append('start_date', startDate);
                                exportUrl.searchParams.append('end_date', endDate);
                                
                                window.location.href = exportUrl.toString();
                            });
                        </script>
                    </form>
                </div>
            </div>

            <?php if($kpiData): ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
                    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400">Total Pendapatan</h4>
                        <p class="mt-1 text-3xl font-semibold text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($kpiData['totalRevenue'], 0, ',', '.')); ?></p>
                    </div>
                    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400">Okupansi Rata-rata</h4>
                        <p class="mt-1 text-3xl font-semibold text-gray-900 dark:text-gray-100"><?php echo e(number_format($kpiData['avgOccupancy'], 2)); ?>%</p>
                    </div>
                    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400">Average Room Rate (ARR)</h4>
                        <p class="mt-1 text-3xl font-semibold text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($kpiData['avgArr'], 0, ',', '.')); ?></p>
                    </div>
                    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400">Revenue Per Available Room (RevPAR)</h4>
                        <p class="mt-1 text-3xl font-semibold text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($kpiData['revPar'], 0, ',', '.')); ?></p>
                    </div>
                    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                        <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400">Resto Revenue Per Room (Sold)</h4>
                        <p class="mt-1 text-3xl font-semibold text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($kpiData['restoRevenuePerRoom'], 0, ',', '.')); ?></p>
                    </div>
                </div>

                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6">
                    <div class="p-6">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Grafik Kinerja Harian</h3>
                        <canvas id="kpiChart"></canvas>
                    </div>
                </div>

                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6">
                    <div class="p-6 grid grid-cols-1 lg:grid-cols-2 gap-x-8 gap-y-6">
                        <div class="space-y-6">
                            <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Rincian Pendapatan</h3>
                            
                            <div>
                                <h4 class="text-base font-medium text-gray-800 dark:text-gray-200 mb-3">Pendapatan Kamar</h4>
                                <ul class="space-y-2">
                                    <?php $__currentLoopData = $kpiData['roomRevenueBreakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="flex justify-between text-sm">
                                            <span class="text-gray-600 dark:text-gray-400"><?php echo e($source); ?></span>
                                            <span class="font-semibold text-gray-800 dark:text-gray-200">Rp <?php echo e(number_format($amount, 0, ',', '.')); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between text-sm font-bold border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                                        <span>Total Pendapatan Kamar</span>
                                        <span>Rp <?php echo e(number_format($kpiData['totalRoomRevenue'], 0, ',', '.')); ?></span>
                                    </li>
                                </ul>
                            </div>

                            <div>
                                <h4 class="text-base font-medium text-gray-800 dark:text-gray-200 mb-3">Pendapatan Lainnya</h4>
                                <ul class="space-y-2">
                                    <?php $__currentLoopData = $kpiData['fbRevenueBreakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between text-sm">
                                        <span class="text-gray-600 dark:text-gray-400"><?php echo e($source); ?></span>
                                        <span class="font-semibold text-gray-800 dark:text-gray-200">Rp <?php echo e(number_format($amount, 0, ',', '.')); ?></span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between text-sm font-bold border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                                        <span>Total F&B</span>
                                        <span>Rp <?php echo e(number_format($kpiData['totalFbRevenue'], 0, ',', '.')); ?></span>
                                    </li>
                                    <li class="pt-2"></li>
                                    <li class="flex justify-between text-sm font-bold border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                                        <span>MICE/Event</span>
                                        <span>Rp <?php echo e(number_format($kpiData['miceRevenue'], 0, ',', '.')); ?></span>
                                    </li>
                                    <li class="flex justify-between text-sm font-bold border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                                        <span>Lain-lain</span>
                                        <span>Rp <?php echo e(number_format($kpiData['totalOtherRevenue'], 0, ',', '.')); ?></span>
                                    </li>
                                </ul>
                            </div>

                            <div class="border-t-2 border-dashed border-gray-300 dark:border-gray-600 pt-3 mt-4">
                                <div class="flex justify-between font-bold text-base">
                                    <span class="text-gray-900 dark:text-gray-100">GRAND TOTAL PENDAPATAN</span>
                                    <span class="text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($kpiData['grandTotalRevenue'], 0, ',', '.')); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-6">
                            <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Rincian Penjualan Kamar</h3>
                            <div>
                                <ul class="space-y-2">
                                     <?php $__currentLoopData = $kpiData['roomsSoldBreakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source => $qty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="flex justify-between text-sm">
                                            <span class="text-gray-600 dark:text-gray-400"><?php echo e($source); ?></span>
                                            <span class="font-semibold text-gray-800 dark:text-gray-200"><?php echo e(number_format($qty)); ?> kamar</span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between text-sm font-bold border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                                        <span>Total Kamar Terjual</span>
                                        <span><?php echo e(number_format($kpiData['totalRoomsSold'])); ?> kamar</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <h3 class="text-lg font-semibold mb-4">Rincian MICE/Event</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nama Klien</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Properti</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Tanggal Event</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Total Harga</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $__empty_1 = true; $__currentLoopData = $miceBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white"><?php echo e($booking->client_name); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"><?php echo e($booking->property->name ?? 'N/A'); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"><?php echo e(\Carbon\Carbon::parse($booking->event_date)->isoFormat('D MMMM YYYY')); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500 dark:text-gray-400">Rp <?php echo e(number_format($booking->total_price, 0, ',', '.')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="px-6 py-4 whitespace-nowrap text-sm text-center text-gray-500 dark:text-gray-400">Tidak ada data MICE/Event pada periode ini.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Tabel Rincian Harian</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Tanggal</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Pendapatan</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Okupansi (%)</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">ARR</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Kamar Terjual</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $__currentLoopData = $dailyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100"><?php echo e($data['date']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Rp <?php echo e(number_format($data['revenue'], 0, ',', '.')); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e(number_format($data['occupancy'], 2)); ?>%</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Rp <?php echo e(number_format($data['arr'], 0, ',', '.')); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($data['rooms_sold']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                     <div class="p-6 text-gray-900 dark:text-gray-100 text-center">
                        <?php if($propertyId): ?>
                            Tidak ada data ditemukan untuk properti dan rentang tanggal yang dipilih.
                        <?php else: ?>
                            Silakan pilih properti dan rentang tanggal untuk memulai analisis.
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            <?php if($kpiData && $dailyData->isNotEmpty()): ?>
                const dailyData = <?php echo json_encode($dailyData, 15, 512) ?>;
                
                const labels = dailyData.map(item => item.date);
                const revenueData = dailyData.map(item => item.revenue);
                const occupancyData = dailyData.map(item => item.occupancy);

                const ctx = document.getElementById('kpiChart').getContext('2d');
                const kpiChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'Pendapatan Harian',
                                data: revenueData,
                                borderColor: 'rgba(54, 162, 235, 1)',
                                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                yAxisID: 'y',
                            },
                            {
                                label: 'Okupansi Harian (%)',
                                data: occupancyData,
                                borderColor: 'rgba(255, 99, 132, 1)',
                                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                yAxisID: 'y1',
                            }
                        ]
                    },
                    options: {
                        scales: {
                            y: {
                                type: 'linear',
                                display: true,
                                position: 'left',
                                ticks: {
                                    callback: function(value) {
                                        return 'Rp ' + new Intl.NumberFormat().format(value);
                                    }
                                }
                            },
                            y1: {
                                type: 'linear',
                                display: true,
                                position: 'right',
                                grid: {
                                    drawOnChartArea: false,
                                },
                                ticks: {
                                     callback: function(value) {
                                        return value + '%';
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/admin/kpi_analysis.blade.php ENDPATH**/ ?>