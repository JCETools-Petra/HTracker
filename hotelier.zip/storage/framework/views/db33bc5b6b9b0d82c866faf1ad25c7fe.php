
<?php
    $indentClass = 'pl-' . ($category['level'] * 6 + 6);
    $isBold = $category['has_children'] || $category['is_payroll'];
    $bgClass = '';

    if ($category['level'] === 0) {
        $bgClass = 'bg-gray-100 dark:bg-gray-700';
    } elseif ($category['is_payroll']) {
        $bgClass = 'bg-yellow-50 dark:bg-yellow-900';
    } elseif ($category['has_children']) {
        $bgClass = 'bg-gray-50 dark:bg-gray-750';
    }
?>

<tr class="<?php echo e($bgClass); ?>">
    <td class="px-6 py-2 text-sm <?php echo e($isBold ? 'font-bold' : ''); ?> text-gray-900 dark:text-gray-100" style="padding-left: <?php echo e(($category['level'] * 1.5 + 1.5)); ?>rem">
        <?php echo e($category['name']); ?>

        <?php if($category['code']): ?>
            <span class="ml-2 text-xs text-blue-600 dark:text-blue-400">(Auto)</span>
        <?php endif; ?>
        <?php if($category['is_payroll']): ?>
            <span class="ml-2 text-xs text-yellow-600 dark:text-yellow-400">(Payroll)</span>
        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-900 dark:text-gray-100">
        <?php if($category['actual_current'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['actual_current'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-900 dark:text-gray-100">
        <?php if($category['budget_current'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['budget_current'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> border-r border-gray-300 <?php echo e($category['variance_current'] >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'); ?>">
        <?php if($category['variance_current'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['variance_current'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-900 dark:text-gray-100">
        <?php if($category['actual_ytd'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['actual_ytd'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> text-gray-900 dark:text-gray-100">
        <?php if($category['budget_ytd'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['budget_ytd'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
    <td class="px-6 py-2 text-right text-sm <?php echo e($isBold ? 'font-semibold' : ''); ?> <?php echo e($category['variance_ytd'] >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'); ?>">
        <?php if($category['variance_ytd'] != 0 || !$category['has_children']): ?>
            Rp <?php echo e(number_format($category['variance_ytd'], 0, ',', '.')); ?>

        <?php endif; ?>
    </td>
</tr>


<?php if($category['has_children'] && count($category['children']) > 0): ?>
    <?php $__currentLoopData = $category['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('financial.partials.category-row', ['category' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hotelier\resources\views/financial/partials/category-row.blade.php ENDPATH**/ ?>