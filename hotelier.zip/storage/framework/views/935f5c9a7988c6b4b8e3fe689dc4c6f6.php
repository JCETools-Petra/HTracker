<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['sizeKey' => 'logo_size']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['sizeKey' => 'logo_size']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
// Ambil pengaturan yang sudah kita share dari AppServiceProvider
$logoPath = $appSettings['logo_path'] ?? null;

// Menggunakan $sizeKey untuk mengambil ukuran yang benar dari array settings.
// Jika 'sidebar_logo_size' dikirim, maka akan digunakan. Jika tidak, akan menggunakan 'logo_size' sebagai default.
$logoSize = $appSettings[$sizeKey] ?? ($appSettings['logo_size'] ?? 80); // Default 80px

$appName = $appSettings['app_name'] ?? config('app.name', 'Laravel');
?>

<?php if($logoPath): ?>
    
    <img src="<?php echo e(asset('storage/' . $logoPath)); ?>" 
         style="height: <?php echo e($logoSize); ?>px;" 
         <?php echo e($attributes->merge(['alt' => 'Logo', 'class' => 'w-auto'])); ?>>
<?php else: ?>
    
    <span <?php echo e($attributes->merge(['class' => 'text-gray-800 dark:text-gray-200 text-2xl font-extrabold'])); ?>>
        <?php echo e($appName); ?>

    </span>
<?php endif; ?><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/components/application-logo.blade.php ENDPATH**/ ?>