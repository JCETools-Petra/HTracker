

<div class="overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Item</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stok</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tgl Pembelian</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Harga Satuan</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Harga</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kondisi</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            <?php $grandTotal = 0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $totalPrice = $inventory->stock * $inventory->unit_price;
                    $grandTotal += $totalPrice;
                ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                        <?php echo e($inventory->name); ?>

                        <div class="text-xs text-gray-500"><?php echo e($inventory->item_code); ?></div>
                        <div class="text-xs text-indigo-400"><?php echo e($inventory->category->name ?? 'Tanpa Kategori'); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100"><?php echo e($inventory->stock); ?> <?php echo e($inventory->unit); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                        <?php echo e($inventory->purchase_date ? \Carbon\Carbon::parse($inventory->purchase_date)->format('d M Y') : 'N/A'); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($inventory->unit_price, 0, ',', '.')); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100"><?php echo e(ucfirst($inventory->condition)); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <a href="<?php echo e(route('admin.inventories.edit', $inventory)); ?>" class="text-indigo-600 hover:text-indigo-900">Edit</a>
                        <form action="<?php echo e(route('admin.inventories.destroy', $inventory)); ?>" method="POST" class="inline-block ml-4" onsubmit="return confirm('Anda yakin ingin menghapus item ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-900">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-6 py-4 text-center text-gray-500">
                        <?php if(isset($search) && $search): ?>
                            Tidak ada inventaris yang cocok dengan pencarian "<?php echo e($search); ?>".
                        <?php else: ?>
                            Belum ada data inventaris untuk properti ini.
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
         <tfoot class="bg-gray-50 dark:bg-gray-700">
             <tr>
                 <td colspan="4" class="px-6 py-3 text-right text-sm font-bold text-gray-600 dark:text-gray-200 uppercase">Total Nilai Inventaris</td>
                 <td class="px-6 py-3 text-left text-sm font-bold text-gray-800 dark:text-white">Rp <?php echo e(number_format($grandTotal, 0, ',', '.')); ?></td>
                 <td colspan="2"></td>
             </tr>
         </tfoot>
    </table>
</div>


<div class="mt-4">
    <?php echo e($inventories->links()); ?>

</div><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/admin/inventories/_table_data.blade.php ENDPATH**/ ?>