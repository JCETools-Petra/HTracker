<tr class="<?php echo e($category->is_payroll ? 'bg-yellow-50 dark:bg-yellow-900' : ''); ?>">
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
        <?php echo e($category->code); ?>

    </td>
    <td class="px-6 py-4 text-sm text-gray-900 dark:text-gray-100">
        <div style="padding-left: <?php echo e($level * 20); ?>px;">
            <?php if($level > 0): ?>
                <span class="text-gray-400"><?php echo e(str_repeat('└─ ', 1)); ?></span>
            <?php endif; ?>
            <span class="font-medium"><?php echo e($category->name); ?></span>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
        <?php echo e($category->property->name ?? '-'); ?>

    </td>
    <td class="px-6 py-4 whitespace-nowrap">
        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($category->type === 'revenue' ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100'); ?>">
            <?php echo e($category->type === 'revenue' ? 'Revenue' : 'Expense'); ?>

        </span>
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
        <?php if($category->is_payroll): ?>
            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-yellow-100">
                Payroll
            </span>
        <?php endif; ?>
        <?php if($category->allows_manual_input): ?>
            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-700 dark:text-blue-100">
                Manual Input
            </span>
        <?php endif; ?>
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <a href="<?php echo e(route('admin.financial-categories.edit', $category->id)); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 mr-3">
            Edit
        </a>
        <form action="<?php echo e(route('admin.financial-categories.destroy', $category->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus kategori ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300">
                Hapus
            </button>
        </form>
    </td>
</tr>

<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('admin.financial-categories.partials.category-row', ['category' => $child, 'level' => $level + 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/admin/financial-categories/partials/category-row.blade.php ENDPATH**/ ?>