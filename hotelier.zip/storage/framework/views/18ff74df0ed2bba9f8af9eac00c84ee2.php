<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="flex flex-wrap justify-between items-center gap-4 mb-4">
                <div>
                    <h1 class="text-2xl font-semibold text-gray-800 dark:text-gray-200">Inventaris untuk <?php echo e($property->name); ?></h1>
                    <a href="<?php echo e(route('admin.inventories.select')); ?>" class="text-sm text-indigo-600 hover:text-indigo-900">Kembali ke pemilihan properti</a>
                </div>
                
                
                <div class="flex items-center gap-2">
                    <a href="<?php echo e(route('admin.inventories.create', ['property_id' => $property->id])); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md font-semibold text-xs uppercase hover:bg-indigo-700">
                        Tambah Item Baru
                    </a>
                    
                    <a href="<?php echo e(route('admin.inventories.export', ['property_id' => $property->id])); ?>" 
                       class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-500 active:bg-green-700 focus:outline-none focus:border-green-700 focus:ring ring-green-300">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                        Download Excel
                    </a>
                </div>
            </div>

            
            <div class="mb-4">
                <form id="search-form" method="GET" action="<?php echo e(route('admin.inventories.index')); ?>">
                    <input type="hidden" name="property_id" value="<?php echo e($property->id); ?>">
                    <div class="relative">
                        <input type="text" name="search" value="<?php echo e($search ?? ''); ?>" placeholder="Cari nama item, kode, atau kategori..." class="w-full pl-4 pr-20 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <button type="submit" class="absolute inset-y-0 right-0 px-4 flex items-center bg-indigo-600 hover:bg-indigo-700 text-white rounded-r-lg">
                            Cari
                        </button>
                    </div>
                </form>
            </div>

            
            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div id="inventory-table-container" class="p-6 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                    <?php echo $__env->make('admin.inventories._table_data', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                 <div class="p-6 bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                     <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 border-b pb-3 dark:border-gray-700">
                         Penjelasan Kolom Aksi
                     </h3>
                     <ul class="mt-4 space-y-3 text-gray-700 dark:text-gray-300">
                         <li><span class="font-bold text-indigo-500">Edit:</span> Untuk mengubah detail item, seperti nama, stok, harga, atau kondisinya.</li>
                         <li><span class="font-bold text-red-500">Hapus:</span> Untuk menghapus item secara permanen dari daftar inventaris.</li>
                     </ul>
                 </div>

                 <div class="p-6 bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                     <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 border-b pb-3 dark:border-gray-700">
                         Legenda Kode Kategori
                     </h3>
                     <ul class="mt-4 space-y-2">
                         <?php $__empty_1 = true; $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                             <li class="flex items-center text-gray-700 dark:text-gray-300">
                                 <span class="font-bold w-20"><?php echo e($category->category_code); ?>:</span>
                                 <span><?php echo e($category->name); ?></span>
                             </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                             <li class="text-gray-500">Belum ada kategori yang dibuat.</li>
                         <?php endif; ?>
                     </ul>
                 </div>
            </div>
        </div>
    </div>

<?php $__env->startPush('scripts'); ?>
<script>
// Script AJAX Anda sudah bagus dan tidak perlu diubah, biarkan seperti ini.
document.addEventListener('DOMContentLoaded', function () {
    const tableContainer = document.getElementById('inventory-table-container');

    // Fungsi untuk mengambil data dan memperbarui tabel
    async function fetchData(url) {
        // Tampilkan indikator loading jika ada
        tableContainer.style.opacity = '0.5';
        
        try {
            const response = await fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            const html = await response.text();
            
            // Perbarui konten dan URL browser
            tableContainer.innerHTML = html;
            window.history.pushState({path: url}, '', url);
        } catch (error) {
            console.error('Gagal mengambil data:', error);
            // Tambahkan notifikasi error jika perlu
        } finally {
            // Hilangkan indikator loading
            tableContainer.style.opacity = '1';
        }
    }

    // Tangani event submit pada form pencarian
    const searchForm = document.getElementById('search-form');
    searchForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Mencegah reload halaman
        const formData = new FormData(searchForm);
        const params = new URLSearchParams(formData);
        const url = `${searchForm.action}?${params.toString()}`;
        fetchData(url);
    });

    // Tangani klik pada link paginasi menggunakan event delegation
    document.addEventListener('click', function (e) {
        // Cek apakah yang diklik adalah link di dalam elemen paginasi
        if (e.target.matches('.pagination a') || e.target.closest('.pagination a')) {
            e.preventDefault();
            const link = e.target.matches('.pagination a') ? e.target : e.target.closest('.pagination a');
            const url = link.href;
            fetchData(url);
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /home/apsx2353/public_html/hoteliermarket.my.id/resources/views/admin/inventories/index.blade.php ENDPATH**/ ?>