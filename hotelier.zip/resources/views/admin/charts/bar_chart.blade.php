{{-- resources/views/admin/charts/bar_chart.blade.php --}}
{{-- Harapkan variabel $chartId --}}
<div style="height: 300px; width: 100%;"> {{-- Sesuaikan ukuran --}}
    <canvas id="{{ $chartId }}"></canvas>
</div>